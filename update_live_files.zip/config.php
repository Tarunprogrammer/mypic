<?php
/**
 * Global Configuration & Helper Functions
 * Face Recognition Photo Retrieval System
 */

// Prevent direct script execution if accessed via command line or include guards
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Database Credentials (InfinityFree Production DB)
define('DB_HOST', 'sql213.infinityfree.com');
define('DB_PORT', '3306');
define('DB_NAME', 'if0_41878641_mypic_db');
define('DB_USER', 'if0_41878641');
define('DB_PASS', 'q69AIGiRBD');
define('DB_CHARSET', 'utf8mb4');

// Base Paths
define('ROOT_DIR', dirname(__DIR__));
define('UPLOAD_DIR', ROOT_DIR . DIRECTORY_SEPARATOR . 'uploads');
define('PHOTO_DIR', UPLOAD_DIR . DIRECTORY_SEPARATOR . 'photos');
define('THUMB_DIR', UPLOAD_DIR . DIRECTORY_SEPARATOR . 'thumbnails');
define('FACE_DIR', UPLOAD_DIR . DIRECTORY_SEPARATOR . 'faces');
define('MODEL_DIR', ROOT_DIR . DIRECTORY_SEPARATOR . 'assets' . DIRECTORY_SEPARATOR . 'models');

// Base URL Auto-detection (Supports root domain like eppe.gt.tc and subfolder like localhost/mypic)
$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || (isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == 443)) ? "https://" : "http://";
$host = isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : 'localhost';
$scriptName = str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? '');
$scriptDir = dirname($scriptName);
if ($scriptDir === '/' || $scriptDir === '\\' || $scriptDir === '.') {
    $scriptDir = '';
}
$basePath = preg_replace('#/(api|admin|config)(/.*)?$#i', '', $scriptDir);
if ($basePath === '/' || $basePath === '\\' || $basePath === '.') {
    $basePath = '';
}
define('BASE_URL', rtrim($protocol . $host . $basePath, '/'));

// Upload limits
define('MAX_UPLOAD_SIZE', 25 * 1024 * 1024); // 25MB
define('ALLOWED_EXTENSIONS', ['jpg', 'jpeg', 'png', 'webp']);

// Gemini AI API Key
define('DEFAULT_GEMINI_API_KEY', 'AQ.Ab8RN6JxLJvDNhOdzs-VQgsAPQCS3iHuiu8MqKqw6Gi4MjyvHg');

/**
 * Return JSON response and exit
 */
function json_response($data, $statusCode = 200) {
    http_response_code($statusCode);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data);
    exit;
}

/**
 * Sanitize string output
 */
function e($string) {
    return htmlspecialchars($string ?? '', ENT_QUOTES, 'UTF-8');
}

/**
 * Check if admin is logged in
 */
function is_admin_logged_in() {
    return isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true && !empty($_SESSION['admin_id']);
}

/**
 * Require admin authentication
 */
function require_admin_login() {
    if (!is_admin_logged_in()) {
        if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest' || strpos($_SERVER['REQUEST_URI'] ?? '', '/api/') !== false) {
            json_response(['success' => false, 'message' => 'Unauthorized. Please log in as admin.'], 401);
        } else {
            header('Location: ' . BASE_URL . '/admin/login.php');
            exit;
        }
    }
}

/**
 * Calculate Euclidean distance between two 128-dimensional float arrays
 * Distance <= 0.6 is typically considered a match with face-api.js / dlib models
 */
function euclidean_distance($vec1, $vec2) {
    $count = count($vec1);
    if ($count !== count($vec2) || $count === 0) {
        return 999.0;
    }
    $sum = 0.0;
    for ($i = 0; $i < $count; $i++) {
        $diff = $vec1[$i] - $vec2[$i];
        $sum += $diff * $diff;
    }
    return sqrt($sum);
}

/**
 * Convert Euclidean distance (0.0 to 1.0) into calibrated match confidence percentage
 * Standard face-api.js / dlib 128D embeddings:
 * Distance <= 0.62 corresponds to >= 50% matching accuracy
 * Distance 0.00 -> 100% Match
 * Distance 0.30 -> ~88% Match
 * Distance 0.45 -> ~74% Match
 * Distance 0.55 -> ~61% Match
 * Distance 0.62 -> 50% Match (Cutoff)
 */
function distance_to_confidence($distance, $threshold = 0.58) {
    if ($distance <= 0) return 100.0;
    if ($distance >= 0.70) return 0.0;
    
    // Calibrated percentage mapping where distance 0.62 = 50.0%
    $confidence = 100.0 - ($distance / 0.62) * 50.0;
    return max(0.0, min(100.0, round($confidence, 1)));
}

/**
 * Generate Thumbnail for uploaded image using GD
 */
function create_thumbnail($sourcePath, $targetPath, $maxDim = 400) {
    if (!file_exists($sourcePath)) return false;
    
    // If GD is not available, safely fallback to copying the file
    if (!function_exists('imagecreatetruecolor') || !function_exists('getimagesize')) {
        return @copy($sourcePath, $targetPath);
    }
    
    $info = @getimagesize($sourcePath);
    if (!$info) {
        return @copy($sourcePath, $targetPath);
    }
    
    $origWidth = $info[0];
    $origHeight = $info[1];
    $mime = $info['mime'];
    
    if ($origWidth <= 0 || $origHeight <= 0) {
        return @copy($sourcePath, $targetPath);
    }
    
    $srcImg = null;
    switch ($mime) {
        case 'image/jpeg':
        case 'image/jpg':
            if (function_exists('imagecreatefromjpeg')) {
                $srcImg = @imagecreatefromjpeg($sourcePath);
            }
            break;
        case 'image/png':
            if (function_exists('imagecreatefrompng')) {
                $srcImg = @imagecreatefrompng($sourcePath);
            }
            break;
        case 'image/webp':
            if (function_exists('imagecreatefromwebp')) {
                $srcImg = @imagecreatefromwebp($sourcePath);
            }
            break;
    }
    
    if (!$srcImg) {
        return @copy($sourcePath, $targetPath);
    }
    
    // Calculate new dimensions preserving aspect ratio
    $ratio = $origWidth / $origHeight;
    if ($origWidth > $origHeight) {
        $newWidth = min($origWidth, $maxDim);
        $newHeight = (int)($newWidth / $ratio);
    } else {
        $newHeight = min($origHeight, $maxDim);
        $newWidth = (int)($newHeight * $ratio);
    }
    
    $thumbImg = imagecreatetruecolor($newWidth, $newHeight);
    if (!$thumbImg) {
        imagedestroy($srcImg);
        return @copy($sourcePath, $targetPath);
    }
    
    // Preserve PNG transparency
    if ($mime === 'image/png' || $mime === 'image/webp') {
        imagealphablending($thumbImg, false);
        imagesavealpha($thumbImg, true);
        $transparent = imagecolorallocatealpha($thumbImg, 255, 255, 255, 127);
        imagefilledrectangle($thumbImg, 0, 0, $newWidth, $newHeight, $transparent);
    }
    
    imagecopyresampled($thumbImg, $srcImg, 0, 0, 0, 0, $newWidth, $newHeight, $origWidth, $origHeight);
    
    // Save as JPEG thumbnail with quality 85
    $saved = imagejpeg($thumbImg, $targetPath, 85);
    
    imagedestroy($srcImg);
    imagedestroy($thumbImg);
    
    return $saved ?: @copy($sourcePath, $targetPath);
}
