<?php
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/api/db.php';

$db = Database::getConnection();
$totalPhotos = (int)$db->query("SELECT COUNT(*) FROM photos")->fetchColumn();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover">
    <title>MYPIC • AI Face Recognition Photo Finder</title>
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@600;700;800;900&family=Plus+Jakarta+Sans:wght@500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/remixicon@4.2.0/fonts/remixicon.css">
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>/assets/css/style.css?v=<?php echo time(); ?>">
</head>
<body>

    <!-- Top Navigation Bar -->
    <nav class="navbar">
        <div class="container nav-content">
            <a href="<?php echo BASE_URL; ?>/" class="brand">
                <div class="brand-icon"><i class="ri-flashlight-fill"></i></div>
                <span class="brand-text">MYPIC</span>
            </a>
            <div class="header-status-chip">
                <span class="pulse-dot"></span>
                <span>AI Face Finder</span>
            </div>
        </div>
    </nav>

    <!-- Main Content Container (Compact Width) -->
    <main class="container">
        
        <!-- Hero Section (Bold Compact Header) -->
        <section class="hero">
            <h1>Find Your Photos with MYPIC</h1>
            <div class="hero-subtitle">Instant AI Face Recognition Search</div>
            <p>
                Scan your face or upload a photo to instantly find and download all your event photos.
            </p>
        </section>

        <!-- Redesigned Biometric HUD Scanning Container -->
        <section class="scanner-card" id="scannerCard">
            <!-- 1. Mode Switcher Tabs -->
            <div class="scanner-tabs">
                <button class="tab-btn active" data-tab="camera">
                    <i class="ri-camera-lens-fill"></i>
                    <span>Quick Scan</span>
                </button>
                <button class="tab-btn" data-tab="multiangle">
                    <i class="ri-sparkling-fill"></i>
                    <span>3D Scan</span>
                </button>
                <button class="tab-btn" data-tab="upload">
                    <i class="ri-upload-cloud-2-line"></i>
                    <span>Upload Photo</span>
                </button>
            </div>

            <!-- 2. Live Camera Scanner Viewport & HUD Deck -->
            <div id="cameraView">
                <!-- 3D Multi-Angle Step Guidance -->
                <div id="multiAngleGuide" class="angle-steps-row" style="display: none;">
                    <div class="angle-step active" id="angleStep1"><i class="ri-user-smile-line"></i> 1. Straight</div>
                    <div class="angle-step" id="angleStep2"><i class="ri-corner-up-left-line"></i> 2. Left</div>
                    <div class="angle-step" id="angleStep3"><i class="ri-corner-up-right-line"></i> 3. Right</div>
                </div>

                <!-- Viewfinder Frame with Corner HUD Brackets -->
                <div class="camera-wrapper">
                    <div class="hud-corner top-left"></div>
                    <div class="hud-corner top-right"></div>
                    <div class="hud-corner bottom-left"></div>
                    <div class="hud-corner bottom-right"></div>

                    <video id="webcamVideo" class="camera-video" autoplay playsinline muted></video>
                    
                    <div class="camera-overlay">
                        <div class="face-guide-oval" id="faceGuideOval"></div>
                        <div class="scan-line"></div>
                    </div>

                    <!-- Top-Right Floating Camera Switcher Button -->
                    <button type="button" class="switch-camera-btn" id="switchCameraBtn" title="Switch Front/Rear Camera" aria-label="Switch Camera">
                        <i class="ri-camera-switch-line"></i>
                    </button>
                </div>

                <!-- Live Scanner Status Feedback -->
                <div class="scanner-status-deck">
                    <span class="status-dot active" id="scannerStatusDot"></span>
                    <span id="scannerStatusText" style="font-size: 0.82rem; font-weight: 700; color: var(--text-secondary);">Position face inside oval</span>
                </div>

                <!-- Integrated Action Deck -->
                <div class="scanner-action-deck">
                    <button type="button" class="btn btn-primary btn-scan-action" id="captureBtn">
                        <i class="ri-camera-fill"></i> Scan & Find My Photos
                    </button>
                    <button type="button" class="btn btn-secondary" id="resetMultiAngleBtn" style="display: none;">
                        <i class="ri-refresh-line"></i> Reset Angles
                    </button>
                </div>
            </div>

            <!-- 3. Selfie Upload Dropzone View -->
            <div id="uploadView" style="display: none;">
                <div class="upload-dropzone" id="uploadDropzone">
                    <input type="file" id="selfieFileInput" accept="image/*" style="display: none;">
                    <div class="dropzone-icon"><i class="ri-image-add-line"></i></div>
                    <h3>Upload a Photo or Selfie</h3>
                    <p>Tap to choose from photo gallery or camera</p>
                    <button type="button" class="btn btn-secondary btn-sm"><i class="ri-folder-image-line"></i> Choose Photo</button>
                </div>

                <!-- Interactive Multi-Face Picker (when photo has multiple people) -->
                <div id="multiFacePickerSection" style="display: none; background: rgba(14, 6, 26, 0.9); border: 1px solid var(--border-glass); border-radius: var(--radius-md); padding: 14px; text-align: center; margin-top: 16px;">
                    <h4 style="color: #fff; font-size: 0.95rem; font-weight: 800; margin-bottom: 6px;"><i class="ri-group-line" style="color: #ec4899;"></i> Multiple faces detected!</h4>
                    <p style="color: var(--text-secondary); font-size: 0.82rem; font-weight: 600; margin-bottom: 12px;">Tap your face to find your photos:</p>
                    <div class="face-picker-grid" id="facePickerGrid"></div>
                </div>

                <!-- Preview of single uploaded selfie -->
                <div id="uploadPreviewWrapper" style="display: none; text-align: center; margin-top: 16px;">
                    <img id="uploadPreviewImg" style="width: 100px; height: 100px; border-radius: 50%; border: 3px solid var(--primary); object-fit: cover; box-shadow: var(--shadow-glow);">
                    <div style="font-size: 0.8rem; font-weight: 700; color: var(--text-secondary); margin-top: 6px;">Processing Face Vectors...</div>
                </div>
            </div>

            <!-- Compact Scanner Footer & Privacy -->
            <div class="scanner-privacy-bar">
                <i class="ri-shield-check-fill"></i>
                <span>100% On-Device AI • Privacy Protected</span>
            </div>
        </section>

        <!-- Matched Photo Results Section (Populated dynamically via JS) -->
        <section class="results-section" id="resultsSection" style="display: none;">
            <div class="results-header">
                <div>
                    <div class="results-title">
                        <i class="ri-sparkling-fill" style="color: #ec4899;"></i>
                        <span>Matched Photos</span>
                        <span class="results-count-badge" id="resultsCount">0 Photos</span>
                    </div>
                    <div style="font-size: 0.82rem; font-weight: 600; color: var(--text-secondary); margin-top: 2px;">
                        All photos identified with your face
                    </div>
                </div>

                <div style="display: flex; align-items: center; gap: 8px; flex-wrap: wrap;">
                    <label id="selectAllWrapper" style="display: none; align-items: center; gap: 8px; background: rgba(255,255,255,0.08); padding: 7px 14px; border-radius: var(--radius-full); cursor: pointer; border: 1px solid var(--border-glass); font-size: 0.82rem; font-weight: 800; color: #f8fafc; user-select: none;">
                        <input type="checkbox" id="selectAllCheckbox" style="width: 16px; height: 16px; accent-color: #ec4899; cursor: pointer;">
                        <span id="selectAllLabel">Select All</span>
                    </label>
                    <button class="btn btn-primary btn-sm" id="downloadSelectedBtn" style="display: none; padding: 8px 16px; font-weight: 800;">
                        <i class="ri-download-cloud-2-line"></i> Download (<span id="selectedCountNum">0</span>)
                    </button>
                </div>
            </div>

            <div class="photo-grid" id="resultsGrid"></div>
        </section>

    </main>

    <!-- Developer Footer -->
    <footer style="border-top: 1px solid var(--border-subtle); padding: 30px 0 34px; margin-top: 48px; text-align: center; color: var(--text-muted); font-size: 0.85rem; background: rgba(14, 6, 28, 0.85); backdrop-filter: blur(20px);">
        <div class="container" style="display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 12px;">
            <div style="display: inline-flex; align-items: center; gap: 10px; background: rgba(26, 14, 48, 0.85); backdrop-filter: blur(16px); padding: 6px 18px; border-radius: 50px; border: 1px solid var(--border-glass); box-shadow: 0 4px 20px rgba(0,0,0,0.4);">
                <img src="<?php echo BASE_URL; ?>/assets/images/developer.jpg" alt="Eppe Tarun" title="Click to view full photo" onclick="Lightbox.open('<?php echo BASE_URL; ?>/assets/images/developer.jpg', 'Eppe Tarun', false)" style="width: 36px; height: 36px; border-radius: 50%; object-fit: cover; object-position: center top; border: 2px solid #ec4899; box-shadow: 0 0 14px rgba(236, 72, 153, 0.5); cursor: pointer;">
                <span style="font-size: 0.88rem; color: var(--text-secondary); font-weight: 600;">
                    Developed by <strong style="color: #ffffff; font-weight: 800; cursor: pointer;" onclick="Lightbox.open('<?php echo BASE_URL; ?>/assets/images/developer.jpg', 'Eppe Tarun', false)">Eppe Tarun</strong>
                </span>
            </div>
            <p style="font-size: 0.82rem; font-weight: 600; color: var(--text-muted); display: flex; align-items: center; justify-content: center; gap: 8px; flex-wrap: wrap;">
                <span>&copy; <?php echo date('Y'); ?> MYPIC • All rights reserved.</span>
                <span>•</span>
                <a href="<?php echo BASE_URL; ?>/admin/login.php" style="color: rgba(255, 255, 255, 0.8); text-decoration: none; font-weight: 700; display: inline-flex; align-items: center; gap: 4px; transition: color 0.2s;" onmouseover="this.style.color='#ec4899'" onmouseout="this.style.color='rgba(255, 255, 255, 0.8)'">
                    <i class="ri-shield-keyhole-line"></i> Admin Login
                </a>
            </p>
        </div>
    </footer>

    <!-- Global Lightbox Modal -->
    <div class="lightbox-modal" id="lightboxModal">
        <div class="lightbox-content">
            <button class="lightbox-close" id="lightboxClose"><i class="ri-close-line"></i></button>
            <img src="" class="lightbox-img" id="lightboxImg">
            <div style="margin-top: 14px; display: flex; align-items: center; justify-content: space-between; width: 100%; gap: 12px; flex-wrap: wrap;">
                <span id="lightboxTitle" style="color: #fff; font-weight: 800; font-size: 0.9rem;"></span>
                <a href="#" id="lightboxDownload" class="btn btn-primary btn-sm" download style="width: 100%; font-weight: 800;"><i class="ri-download-2-line"></i> Download Photo</a>
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="<?php echo BASE_URL; ?>/assets/js/face-api.min.js"></script>
    <script src="<?php echo BASE_URL; ?>/assets/js/main.js?v=<?php echo time(); ?>"></script>
    <script src="<?php echo BASE_URL; ?>/assets/js/face-scanner.js?v=<?php echo time(); ?>"></script>
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            FaceScanner.init('<?php echo BASE_URL; ?>/assets/models');
        });
    </script>
</body>
</html>
